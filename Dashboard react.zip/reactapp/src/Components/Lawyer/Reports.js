import * as React from 'react';

export default function Reports() {
  return (
    <>
    <h1>Report</h1>
    </>
  );
}
