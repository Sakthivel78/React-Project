import * as React from 'react';

export default function CaseRecords() {
  return (
    <>
    <h1>CaseRecord</h1>
    </>
  );
}
